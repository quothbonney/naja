#pragma once
#include <Eigen/Dense>
#include <fstream>
#include <vector>
#include <string>
#include <iostream>
#include <stdexcept>
#include <sstream>
#include <cstring>
#include <algorithm>
#include <cstdint>
#include "checked_size.h"

namespace npy {

// Write Eigen matrix to .npy format (C-contiguous, float64)
inline void save(const std::string& filename, const Eigen::MatrixXd& mat) {
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot write file: " + filename);
    }
    
    // Magic string
    file.write("\x93NUMPY", 6);
    
    // Version 1.0
    file.put(0x01);
    file.put(0x00);
    
    // Create header dict
    std::ostringstream header;
    header << "{'descr': '<f8', 'fortran_order': False, 'shape': (";
    header << mat.rows() << ", " << mat.cols() << "), }";
    
    // Pad header to multiple of 64 bytes (including length prefix)
    std::string header_str = header.str();
    size_t total_header_len = 6 + 2 + 2 + header_str.size();  // magic + version + len + dict
    size_t padding = (64 - (total_header_len % 64)) % 64;
    header_str.append(padding, ' ');
    header_str.push_back('\n');
    
    // Write header length (little-endian uint16)
    uint16_t header_len = header_str.size();
    file.write(reinterpret_cast<const char*>(&header_len), 2);
    
    // Write header
    file.write(header_str.c_str(), header_len);
    
    // Write data in row-major (C) order
    // Eigen is column-major by default. Copy to RowMajor temp then write block.
    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> mat_row = mat;
    file.write(reinterpret_cast<const char*>(mat_row.data()), naja::checked_streamsize(naja::checked_matrix_bytes<double>(mat.rows(), mat.cols(), "NPY output"), "NPY output"));
    
    file.close();
    if (!file) throw std::runtime_error("Failed writing NPY file: " + filename);
}

// Write a 1D uint8 array to .npy (C-contiguous, shape (N,))
inline void save_u8_1d(const std::string& filename, const std::vector<uint8_t>& v) {
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot write file: " + filename);
    }

    file.write("\x93NUMPY", 6);
    file.put(0x01);
    file.put(0x00);

    std::ostringstream header;
    header << "{'descr': '|u1', 'fortran_order': False, 'shape': (";
    header << v.size() << ",), }";

    std::string header_str = header.str();
    size_t total_header_len = 6 + 2 + 2 + header_str.size();
    size_t padding = (64 - (total_header_len % 64)) % 64;
    header_str.append(padding, ' ');
    header_str.push_back('\n');

    uint16_t header_len = header_str.size();
    file.write(reinterpret_cast<const char*>(&header_len), 2);
    file.write(header_str.c_str(), header_len);

    if (!v.empty()) {
        file.write(reinterpret_cast<const char*>(v.data()), static_cast<std::streamsize>(v.size()));
    }
    file.close();
    if (!file) throw std::runtime_error("Failed writing NPY file: " + filename);
}

// Write Eigen matrix as (cols, rows) float32 .npy — zero-copy transpose trick.
//
// Eigen col-major (R, C) has columns contiguous in memory. Writing that raw
// memory as C-order shape (C, R) means numpy reads row k = Eigen column k.
// For samples_out of shape (dim, n_samples), the file becomes (n_samples, dim)
// with each row being one contiguous sample vector — exactly what downstream
// consumers want. The only work is the float64->float32 downcast.
//
// This is FASTER than the old save(): no RowMajor conversion copy, and half
// the bytes written to disk.
inline void save_f32_samples(const std::string& filename, const Eigen::MatrixXd& mat) {
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot write file: " + filename);
    }

    // File shape is (cols, rows) — the "transpose" of the Eigen shape
    const Eigen::Index file_rows = mat.cols();
    const Eigen::Index file_cols = mat.rows();

    // Magic + version
    file.write("\x93NUMPY", 6);
    file.put(0x01);
    file.put(0x00);

    // Header: float32, C-contiguous, shape (n_samples, dim)
    std::ostringstream header;
    header << "{'descr': '<f4', 'fortran_order': False, 'shape': ("
           << file_rows << ", " << file_cols << "), }";

    std::string header_str = header.str();
    size_t total_header_len = 6 + 2 + 2 + header_str.size();
    size_t padding = (64 - (total_header_len % 64)) % 64;
    header_str.append(padding, ' ');
    header_str.push_back('\n');

    uint16_t header_len = header_str.size();
    file.write(reinterpret_cast<const char*>(&header_len), 2);
    file.write(header_str.c_str(), header_len);

    // Downcast float64 -> float32 in chunks and write.
    // Process one Eigen column (= one sample) at a time to stay cache-friendly.
    // Each column is contiguous in memory (Eigen col-major).
    const size_t n_elements = (size_t)mat.rows();
    std::vector<float> buf(n_elements);
    for (Eigen::Index c = 0; c < mat.cols(); ++c) {
        const double* src = mat.data() + (size_t)c * n_elements;
        for (size_t i = 0; i < n_elements; ++i) {
            buf[i] = static_cast<float>(src[i]);
        }
        file.write(reinterpret_cast<const char*>(buf.data()),
                    naja::checked_streamsize(naja::checked_size_mul(n_elements, sizeof(float), "NPY float32 column"), "NPY float32 column"));
    }

    file.close();
    if (!file) throw std::runtime_error("Failed writing NPY file: " + filename);
}

// Write Eigen col-major samples directly as C-order (samples, dimensions) float64.
// Sampling is already double precision; this path avoids a lossy export cast.
inline void save_f64_samples(const std::string& filename, const Eigen::MatrixXd& mat) {
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) throw std::runtime_error("Cannot write file: " + filename);
    file.write("\x93NUMPY", 6);
    file.put(0x01);
    file.put(0x00);
    std::ostringstream header;
    header << "{'descr': '<f8', 'fortran_order': False, 'shape': ("
           << mat.cols() << ", " << mat.rows() << "), }";
    std::string header_str = header.str();
    const size_t total_header_len = 6 + 2 + 2 + header_str.size() + 1; // include final newline
    header_str.append((64 - (total_header_len % 64)) % 64, ' ');
    header_str.push_back('\n');
    const uint16_t header_len = static_cast<uint16_t>(header_str.size());
    file.write(reinterpret_cast<const char*>(&header_len), 2);
    file.write(header_str.data(), header_len);
    const size_t bytes = naja::checked_matrix_bytes<double>(mat.rows(), mat.cols(), "NPY float64 output");
    file.write(reinterpret_cast<const char*>(mat.data()), naja::checked_streamsize(bytes, "NPY float64 output"));
    file.close();
    if (!file) throw std::runtime_error("Failed writing samples: " + filename);
}

// Load NPY file.
// OPTIMIZATION: Returns the matrix transposed (cols, rows) relative to file shape!
// File shape (R, C) C-order -> Eigen Matrix (C, R) Col-order.
// This avoids data shuffling and is essentially free.
// Caller must interpret dimensions accordingly.
inline Eigen::MatrixXd load_transposed(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open()) throw std::runtime_error("Cannot open " + filename);
    
    char magic[6] = {};
    file.read(magic, 6);
    if (std::strncmp(magic, "\x93NUMPY", 6) != 0) throw std::runtime_error("Invalid NPY file");
    
    char version[2] = {};
    file.read(version, 2);
    
    uint16_t header_len = 0;
    file.read(reinterpret_cast<char*>(&header_len), 2);
    
    std::string header(header_len, ' ');
    file.read(&header[0], header_len);
    if (!file) throw std::runtime_error("Truncated NPY header: " + filename);
    
    // Parse shape
    size_t shape_pos = header.find("'shape':");
    if (shape_pos == std::string::npos) throw std::runtime_error("Missing shape in NPY header");
    
    size_t start = header.find('(', shape_pos);
    size_t end = header.find(')', start);
    std::string shape_str = header.substr(start + 1, end - start - 1);
    
    std::replace(shape_str.begin(), shape_str.end(), ',', ' ');
    std::stringstream ss(shape_str);
    Eigen::Index rows = 0, cols = 0;
    if (!(ss >> rows >> cols) || rows < 0 || cols < 0) throw std::runtime_error("Invalid NPY shape");
    const std::size_t data_bytes = naja::checked_matrix_bytes<double>(rows, cols, "NPY input");
    
    // Check fortran_order
    bool fortran_order = header.find("'fortran_order': True") != std::string::npos;
    
    if (fortran_order) {
        // File is Col-major (R, C). Read into (R, C) Col-major.
        Eigen::MatrixXd mat(rows, cols);
        file.read(reinterpret_cast<char*>(mat.data()), naja::checked_streamsize(data_bytes, "NPY input"));
        if (!file) throw std::runtime_error("Truncated NPY data: " + filename);
        // We promised transpose? No, this returns original.
        // This case is rare for NPY saved by numpy or us.
        // If we want consistent behavior (Transpose), we should transpose this?
        // For now, assume C-order (default).
        return mat.transpose(); 
    } else {
        // File is Row-major (R, C).
        // Data in file: Row 0, Row 1...
        // Read into Eigen Matrix (C, R) Col-major.
        // Eigen Col-major stores Col 0, Col 1...
        // So mat(c, r) stores data[c + r*C].
        // File data[k] = data[c + r*C].
        // This corresponds to mat(c, r) = file[r, c].
        // So the matrix we get is the Transpose of the file matrix.
        
        Eigen::MatrixXd mat(cols, rows);
        file.read(reinterpret_cast<char*>(mat.data()), naja::checked_streamsize(data_bytes, "NPY input"));
        if (!file) throw std::runtime_error("Truncated NPY data: " + filename);
        return mat;
    }
}

// Standard load (slow if C-order) - kept for compatibility if needed, 
// but we prefer load_transposed for speed.
inline Eigen::MatrixXd load(const std::string& filename) {
    // For coloring tool, we use load_transposed logic manually or call it.
    // If user calls load(), they expect (R, C).
    // We can implement load() by calling load_transposed() and transposing back.
    // Transposing in memory is fast (1s for 3GB).
    return load_transposed(filename).transpose();
}

} // namespace npy
