#pragma once
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <nvtx3/nvToolsExt.h>

namespace naja::profiling {
class BarrierSpan {
    const char* name_;
    bool enabled_;
    std::chrono::steady_clock::time_point start_;
public:
    explicit BarrierSpan(const char* name) : name_(name),
        enabled_(std::getenv("NAJA_BARRIER_TRACE") != nullptr),
        start_(std::chrono::steady_clock::now()) {
        if (enabled_) nvtxRangePushA(name_);
    }
    ~BarrierSpan() {
        if (!enabled_) return;
        const double seconds = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - start_).count();
        nvtxRangePop();
        std::cerr << "NAJA_BARRIER_STAGE {\"name\":\"" << name_
                  << "\",\"seconds\":" << std::setprecision(17) << seconds << "}\n";
    }
    BarrierSpan(const BarrierSpan&) = delete;
    BarrierSpan& operator=(const BarrierSpan&) = delete;
};
}
